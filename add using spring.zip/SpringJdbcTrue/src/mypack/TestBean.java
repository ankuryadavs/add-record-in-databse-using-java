package mypack;
import java .sql.*;
import javax.sql.DataSource;
public class TestBean implements Test{
	private DataSource dataSource;
	private PreparedStatement pst;
	private String sql;
	private Connection conn;



	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}
    public int addRecord(Employee e)throws SQLException
     {
    	 sql="insert into test values(?,?,?)";
    	 conn=dataSource.getConnection();
    	 pst=conn.prepareStatement(sql);
    	 pst.setInt(1, e.getEno());
    	 pst.setString(2, e.getEname());
    	 pst.setInt(3, e.getEsal());
    	 return pst.executeUpdate();
     }
}
