package mypack;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import java.util.*;
import java.sql.*;
public class TestClient {
	public static void main(String args[])throws SQLException
	{
	    ApplicationContext ac=new ClassPathXmlApplicationContext("TestCfg.xml");
		Test t=(Test)ac.getBean("tb");
		Scanner sc=new Scanner(System.in);
		Employee e=new Employee();
		System.out.println("enter the eno");
		int eno=sc.nextInt();
		e.setEno(eno);
		System.out.println("enter the ename");
		String ename=sc.next();
		e.setEname(ename);
		System.out.println("enter the esal");
		int esal=sc.nextInt();
		e.setEsal(esal);
		int x=t.addRecord(e);
		System.out.println(x);
	}

}
