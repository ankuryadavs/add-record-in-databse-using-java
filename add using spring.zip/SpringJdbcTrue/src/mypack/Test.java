package mypack;
import java.sql.*;
public interface Test {
   public int addRecord(Employee e)throws SQLException;
}
